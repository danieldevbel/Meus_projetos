export const listaPalavras = {
    carro: ["Motor", "Porta", "Capô", "Pneu", "Antena"],
    fruta: ["Banana", "Maçã", "Pêra", "Mamão", "Laranja"],
    corpo: ["Braço", "Perna", "Cérebro", "Pescoço", "Olhos"],
    computador: ["Mouse", "Teclado", "Monitor", "Gabinete"],
    programação: ["Linguagem", "Framework", "JavaScript", "React"],
    alimento: ["Arroz", "Feijão", "Carne", "Leite", "Ovo"],
};